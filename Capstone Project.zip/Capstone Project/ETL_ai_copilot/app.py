import streamlit as st

from agents.log_parser import LogParser
from agents.retriever_agent import RetrieverAgent
from agents.resolution_agent import ResolutionAgent

st.title("AI ETL Production Support Copilot")

parser = LogParser()
retriever = RetrieverAgent()
resolver = ResolutionAgent()

log_input = st.text_area(
    "Paste ETL Failure Logs"
)

if st.button("Analyze Failure"):

    parsed_result = parser.parse_log(
        log_input
    )

    context = retriever.retrieve_context(
        parsed_result["error_type"]
    )

    solution = resolver.generate_solution(
        log_input,
        context
    )

    st.subheader("Parsed Incident")
    st.json(parsed_result)

    st.subheader("Retrieved SOP/RCA Context")
    st.write(context)

    st.subheader("AI Resolution")
    st.write(solution)
