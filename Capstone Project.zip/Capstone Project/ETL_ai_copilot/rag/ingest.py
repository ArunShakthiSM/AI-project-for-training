from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma

from config import (
    CHROMA_DB_PATH,
    EMBEDDING_MODEL
)

sop_loader = TextLoader("data/sop.txt")
rca_loader = TextLoader("data/rca.txt")

sop_docs = sop_loader.load()
rca_docs = rca_loader.load()

all_docs = sop_docs + rca_docs

splitter = RecursiveCharacterTextSplitter(
    chunk_size=300,
    chunk_overlap=50
)

chunks = splitter.split_documents(all_docs)

embeddings = HuggingFaceEmbeddings(
    model_name=EMBEDDING_MODEL
)

vectordb = Chroma.from_documents(
    documents=chunks,
    embedding=embeddings,
    persist_directory=CHROMA_DB_PATH
)

vectordb.persist()

print("Documents ingested successfully")
