from langchain_community.llms import Ollama
from config import OLLAMA_MODEL

class ResolutionAgent:

    def __init__(self):

        self.llm = Ollama(
            model=OLLAMA_MODEL
        )

    def generate_solution(
        self,
        issue,
        context
    ):

        prompt = f"""
        You are a senior ETL production support engineer.

        Analyze this ETL issue carefully.

        Issue:
        {issue}

        Reference SOP/RCA:
        {context}

        Provide:
        1. Root Cause
        2. Safe Resolution Steps
        3. Validation Steps
        4. Escalation Recommendation

        Avoid risky SQL operations.
        """

        response = self.llm.invoke(prompt)

        return response
