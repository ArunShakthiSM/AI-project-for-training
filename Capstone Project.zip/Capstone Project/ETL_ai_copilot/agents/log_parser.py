class LogParser:

    def parse_log(self, log_text):

        result = {
            "error_type": "Unknown",
            "severity": "Medium"
        }

        if "ORA-01652" in log_text:
            result["error_type"] = "TEMP Tablespace Full"
            result["severity"] = "High"

        elif "ORA-00054" in log_text:
            result["error_type"] = "Database Lock"
            result["severity"] = "High"

        elif "timeout" in log_text.lower():
            result["error_type"] = "Connection Timeout"
            result["severity"] = "Medium"

        return result
