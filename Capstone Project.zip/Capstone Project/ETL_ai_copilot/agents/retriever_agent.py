from rag.vectordb import vectordb

class RetrieverAgent:

    def retrieve_context(self, query):

        docs = vectordb.similarity_search(
            query,
            k=3
        )

        context = ""

        for doc in docs:
            context += doc.page_content + "\n\n"

        return context
